package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun irAPrincipal(view: View) {
        val intent = Intent(this@MainActivity, Principal::class.java)
        startActivity(intent)
    }
    fun irAEnlaces(view: View) {
        val intent = Intent(this@MainActivity, Instituto::class.java)
        startActivity(intent)
    }
}