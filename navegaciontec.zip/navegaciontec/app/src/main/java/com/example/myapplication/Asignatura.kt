package com.example.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class Asignatura : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_asignatura)
    }

    fun irAPrincipal(view: View) {
        val intent = Intent(this@Asignatura, Principal::class.java)
        startActivity(intent)
    }
}